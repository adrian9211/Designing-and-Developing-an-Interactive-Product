create definer = `mariadb.sys`@localhost view session as
select `processlist`.`thd_id`                 AS `thd_id`,
       `processlist`.`conn_id`                AS `conn_id`,
       `processlist`.`user`                   AS `user`,
       `processlist`.`db`                     AS `db`,
       `processlist`.`command`                AS `command`,
       `processlist`.`state`                  AS `state`,
       `processlist`.`time`                   AS `time`,
       `processlist`.`current_statement`      AS `current_statement`,
       `processlist`.`statement_latency`      AS `statement_latency`,
       `processlist`.`progress`               AS `progress`,
       `processlist`.`lock_latency`           AS `lock_latency`,
       `processlist`.`rows_examined`          AS `rows_examined`,
       `processlist`.`rows_sent`              AS `rows_sent`,
       `processlist`.`rows_affected`          AS `rows_affected`,
       `processlist`.`tmp_tables`             AS `tmp_tables`,
       `processlist`.`tmp_disk_tables`        AS `tmp_disk_tables`,
       `processlist`.`full_scan`              AS `full_scan`,
       `processlist`.`last_statement`         AS `last_statement`,
       `processlist`.`last_statement_latency` AS `last_statement_latency`,
       `processlist`.`current_memory`         AS `current_memory`,
       `processlist`.`last_wait`              AS `last_wait`,
       `processlist`.`last_wait_latency`      AS `last_wait_latency`,
       `processlist`.`source`                 AS `source`,
       `processlist`.`trx_latency`            AS `trx_latency`,
       `processlist`.`trx_state`              AS `trx_state`,
       `processlist`.`trx_autocommit`         AS `trx_autocommit`,
       `processlist`.`pid`                    AS `pid`,
       `processlist`.`program_name`           AS `program_name`
from `sys`.`processlist`
where `processlist`.`conn_id` is not null
  and `processlist`.`command` <> 'Daemon';

-- comment on column session.thd_id not supported: A unique thread identifier.

-- comment on column session.conn_id not supported: The PROCESSLIST.ID value for threads displayed in the INFORMATION_SCHEMA.PROCESSLIST table, or 0 for background threads. Also corresponds with the CONNECTION_ID() return value for the thread.

-- comment on column session.db not supported: Thread's default database, or NULL if none exists.

-- comment on column session.command not supported: Type of command executed by the thread. These correspond to the the COM_xxx client/server protocol commands, and the Com_xxx status variables. See Thread Command Values.

-- comment on column session.state not supported: Action, event or state indicating what the thread is doing.

-- comment on column session.time not supported: Time in seconds the thread has been in its current state.

-- comment on column session.rows_examined not supported: Number of rows read during the statement's execution.

-- comment on column session.rows_sent not supported: Number of rows returned.

-- comment on column session.rows_affected not supported: Number of rows affected the statement affected.

-- comment on column session.tmp_tables not supported: Number of temp tables created by the statement.

-- comment on column session.tmp_disk_tables not supported: Number of on-disk temp tables created by the statement.

-- comment on column session.last_wait not supported: Event instrument name and a NAME from the setup_instruments table

-- comment on column session.source not supported: Name and line number of the source file containing the instrumented code that produced the event.

-- comment on column session.trx_state not supported: The current transaction state. The value is ACTIVE (after START TRANSACTION or BEGIN), COMMITTED (after COMMIT), or ROLLED BACK (after ROLLBACK).

-- comment on column session.trx_autocommit not supported: Whether autcommit mode was enabled when the transaction started.

-- comment on column session.pid not supported: Attribute value.

-- comment on column session.program_name not supported: Attribute value.

