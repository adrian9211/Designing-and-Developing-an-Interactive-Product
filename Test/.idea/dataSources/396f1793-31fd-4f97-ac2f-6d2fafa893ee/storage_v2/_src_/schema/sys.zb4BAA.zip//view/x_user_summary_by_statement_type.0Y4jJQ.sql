create definer = `mariadb.sys`@localhost view x$user_summary_by_statement_type as
select if(`performance_schema`.`events_statements_summary_by_user_by_event_name`.`USER` is null, 'background',
          `performance_schema`.`events_statements_summary_by_user_by_event_name`.`USER`)                             AS `user`,
       substring_index(`performance_schema`.`events_statements_summary_by_user_by_event_name`.`EVENT_NAME`, '/',
                       -1)                                                                                           AS `statement`,
       `performance_schema`.`events_statements_summary_by_user_by_event_name`.`COUNT_STAR`                           AS `total`,
       `performance_schema`.`events_statements_summary_by_user_by_event_name`.`SUM_TIMER_WAIT`                       AS `total_latency`,
       `performance_schema`.`events_statements_summary_by_user_by_event_name`.`MAX_TIMER_WAIT`                       AS `max_latency`,
       `performance_schema`.`events_statements_summary_by_user_by_event_name`.`SUM_LOCK_TIME`                        AS `lock_latency`,
       `performance_schema`.`events_statements_summary_by_user_by_event_name`.`SUM_ROWS_SENT`                        AS `rows_sent`,
       `performance_schema`.`events_statements_summary_by_user_by_event_name`.`SUM_ROWS_EXAMINED`                    AS `rows_examined`,
       `performance_schema`.`events_statements_summary_by_user_by_event_name`.`SUM_ROWS_AFFECTED`                    AS `rows_affected`,
       `performance_schema`.`events_statements_summary_by_user_by_event_name`.`SUM_NO_INDEX_USED` +
       `performance_schema`.`events_statements_summary_by_user_by_event_name`.`SUM_NO_GOOD_INDEX_USED`               AS `full_scans`
from `performance_schema`.`events_statements_summary_by_user_by_event_name`
where `performance_schema`.`events_statements_summary_by_user_by_event_name`.`SUM_TIMER_WAIT` <> 0
order by if(`performance_schema`.`events_statements_summary_by_user_by_event_name`.`USER` is null, 'background',
            `performance_schema`.`events_statements_summary_by_user_by_event_name`.`USER`),
         `performance_schema`.`events_statements_summary_by_user_by_event_name`.`SUM_TIMER_WAIT` desc;

-- comment on column x$user_summary_by_statement_type.total not supported: Number of summarized events

-- comment on column x$user_summary_by_statement_type.total_latency not supported: Total wait time of the summarized events that are timed.

-- comment on column x$user_summary_by_statement_type.max_latency not supported: Maximum wait time of the summarized events that are timed.

-- comment on column x$user_summary_by_statement_type.lock_latency not supported: Sum of the LOCK_TIME column in the events_statements_current table.

-- comment on column x$user_summary_by_statement_type.rows_sent not supported: Sum of the ROWS_SENT column in the events_statements_current table.

-- comment on column x$user_summary_by_statement_type.rows_examined not supported: Sum of the ROWS_EXAMINED column in the events_statements_current table.

-- comment on column x$user_summary_by_statement_type.rows_affected not supported: Sum of the ROWS_AFFECTED column in the events_statements_current table.

