create definer = `mariadb.sys`@localhost view statements_with_runtimes_in_95th_percentile as
select `sys`.`format_statement`(`stmts`.`DIGEST_TEXT`)                                      AS `query`,
       `stmts`.`SCHEMA_NAME`                                                                AS `db`,
       if(`stmts`.`SUM_NO_GOOD_INDEX_USED` > 0 or `stmts`.`SUM_NO_INDEX_USED` > 0, '*', '') AS `full_scan`,
       `stmts`.`COUNT_STAR`                                                                 AS `exec_count`,
       `stmts`.`SUM_ERRORS`                                                                 AS `err_count`,
       `stmts`.`SUM_WARNINGS`                                                               AS `warn_count`,
       `sys`.`format_time`(`stmts`.`SUM_TIMER_WAIT`)                                        AS `total_latency`,
       `sys`.`format_time`(`stmts`.`MAX_TIMER_WAIT`)                                        AS `max_latency`,
       `sys`.`format_time`(`stmts`.`AVG_TIMER_WAIT`)                                        AS `avg_latency`,
       `stmts`.`SUM_ROWS_SENT`                                                              AS `rows_sent`,
       round(ifnull(`stmts`.`SUM_ROWS_SENT` / nullif(`stmts`.`COUNT_STAR`, 0), 0), 0)       AS `rows_sent_avg`,
       `stmts`.`SUM_ROWS_EXAMINED`                                                          AS `rows_examined`,
       round(ifnull(`stmts`.`SUM_ROWS_EXAMINED` / nullif(`stmts`.`COUNT_STAR`, 0), 0), 0)   AS `rows_examined_avg`,
       `stmts`.`FIRST_SEEN`                                                                 AS `first_seen`,
       `stmts`.`LAST_SEEN`                                                                  AS `last_seen`,
       `stmts`.`DIGEST`                                                                     AS `digest`
from (`performance_schema`.`events_statements_summary_by_digest` `stmts` join `sys`.`x$ps_digest_95th_percentile_by_avg_us` `top_percentile`
      on (round(`stmts`.`AVG_TIMER_WAIT` / 1000000, 0) >= `top_percentile`.`avg_us`))
order by `stmts`.`AVG_TIMER_WAIT` desc;

-- comment on column statements_with_runtimes_in_95th_percentile.db not supported: Database name. Records are summarised together with DIGEST.

-- comment on column statements_with_runtimes_in_95th_percentile.exec_count not supported: Number of summarized events

-- comment on column statements_with_runtimes_in_95th_percentile.err_count not supported: Sum of the ERRORS column in the events_statements_current table.

-- comment on column statements_with_runtimes_in_95th_percentile.warn_count not supported: Sum of the WARNINGS column in the events_statements_current table.

-- comment on column statements_with_runtimes_in_95th_percentile.rows_sent not supported: Sum of the ROWS_SENT column in the events_statements_current table.

-- comment on column statements_with_runtimes_in_95th_percentile.rows_examined not supported: Sum of the ROWS_EXAMINED column in the events_statements_current table.

-- comment on column statements_with_runtimes_in_95th_percentile.first_seen not supported: Time at which the digest was first seen.

-- comment on column statements_with_runtimes_in_95th_percentile.last_seen not supported: Time at which the digest was most recently seen.

-- comment on column statements_with_runtimes_in_95th_percentile.digest not supported: Performance Schema digest. Records are summarised together with SCHEMA NAME.

